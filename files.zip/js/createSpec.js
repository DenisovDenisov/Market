describe("Jasmine", function() {
  it("makes testing JavaScript awesome!", function() {
    expect(shop1.name).toBe('shop21');
  });
});


