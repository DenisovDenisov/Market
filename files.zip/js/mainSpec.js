describe("Проверка экземпляра", function() {
  it("Значени не должно быть Undefined", function() {
    expect(shop1).toBeDefined();
  });
});

